# RecursiveCharacterTextSplitter

A small, original, recursive character splitter with a simple local UI for taking a `.zip` of Markdown chunks and splitting those chunks into smaller Markdown files.

## What it does

- Accepts a `.zip` created by your Markdown header splitter or any `.zip` containing `.md` files
- Recursively splits each Markdown file by natural separators like blank lines, lines, sentence endings, spaces, and finally raw character windows
- Lets you choose `chunk_size` and `chunk_overlap`
- Outputs a new downloadable `.zip` containing the re-split Markdown chunks and a manifest JSON file
- Keeps the implementation lightweight and original instead of copying third-party splitter code

## Install

```bash
pip install RecursiveCharacterTextSplitter
```

## Run

```bash
RecursiveCharacterTextSplitter
```

This launches a local Streamlit app in your browser.

## Notes

- This package does **not** vendor or copy code from LangChain or other companies.
- The idea of recursive text splitting is common, but you should still do your own final name, trademark, licensing, and patent review before publishing publicly.
- PyPI package-name availability can change over time, so confirm the final project name before upload.

## File structure

```text
RecursiveCharacterTextSplitter_pypi/
  README.md
  LICENSE
  pyproject.toml
  recursivecharactertextsplitter/
    __init__.py
    app.py
    cli.py
    core.py
  dist/
    recursivecharactertextsplitter-0.1.0.tar.gz
    recursivecharactertextsplitter-0.1.0-py3-none-any.whl
```
