from __future__ import annotations

from io import BytesIO
import json
from pathlib import Path
import re
from typing import Iterable
import zipfile


DEFAULT_SEPARATORS = ["\n\n", "\n", ". ", " "]


def _normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _window_split(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if chunk_size <= 0:
        return [text + "\n"]

    step = max(1, chunk_size - max(0, chunk_overlap))
    parts: list[str] = []
    start = 0
    while start < len(text):
        piece = text[start : start + chunk_size].strip()
        if piece:
            parts.append(piece + "\n")
        if start + chunk_size >= len(text):
            break
        start += step
    return parts


def _split_by_separator(text: str, separator: str) -> list[str]:
    if not separator:
        return list(text)
    if separator == " ":
        words = text.split(" ")
        return [w for w in words if w != ""]
    if separator == ". ":
        parts = re.split(r"(?<=\.)\s+", text)
        return [p for p in parts if p.strip()]
    return [p for p in text.split(separator) if p.strip()]


def _join_with_separator(parts: list[str], separator: str) -> str:
    if not parts:
        return ""
    if separator == " ":
        return " ".join(p.strip() for p in parts if p.strip())
    if separator == ". ":
        return " ".join(p.strip() for p in parts if p.strip())
    return separator.join(p.strip("\n") for p in parts if p.strip())


def _pack_parts(parts: list[str], separator: str, chunk_size: int) -> list[str]:
    packed: list[str] = []
    bucket: list[str] = []

    for part in parts:
        candidate = _join_with_separator(bucket + [part], separator)
        if bucket and len(candidate) > chunk_size:
            packed.append(_join_with_separator(bucket, separator))
            bucket = [part]
        else:
            bucket.append(part)

    if bucket:
        packed.append(_join_with_separator(bucket, separator))
    return [p.strip() for p in packed if p.strip()]


def _recursive_split(text: str, separators: list[str], chunk_size: int) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]
    if not separators:
        return _window_split(text, chunk_size, 0)

    separator = separators[0]
    parts = _split_by_separator(text, separator)
    if len(parts) <= 1:
        return _recursive_split(text, separators[1:], chunk_size)

    packed = _pack_parts(parts, separator, chunk_size)
    out: list[str] = []
    for piece in packed:
        if len(piece) <= chunk_size:
            out.append(piece)
        else:
            out.extend(_recursive_split(piece, separators[1:], chunk_size))
    return [p.strip() for p in out if p.strip()]


def _apply_overlap(chunks: list[str], chunk_overlap: int) -> list[str]:
    if chunk_overlap <= 0 or len(chunks) <= 1:
        return [c.strip() + "\n" for c in chunks if c.strip()]

    out: list[str] = []
    previous = ""
    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue
        prefix = previous[-chunk_overlap:].strip()
        if prefix and not chunk.startswith(prefix):
            merged = (prefix + "\n\n" + chunk).strip() + "\n"
        else:
            merged = chunk + "\n"
        out.append(merged)
        previous = chunk
    return out


def recursive_split_text(
    text: str,
    *,
    chunk_size: int = 1200,
    chunk_overlap: int = 150,
    separators: Iterable[str] | None = None,
) -> list[str]:
    text = _normalize_newlines(text).strip("\n")
    if not text:
        return []
    chunk_size = max(1, int(chunk_size))
    chunk_overlap = max(0, min(int(chunk_overlap), chunk_size - 1 if chunk_size > 1 else 0))
    sep_list = [str(s) for s in (separators or DEFAULT_SEPARATORS)]

    base_chunks = _recursive_split(text, sep_list, chunk_size)
    if not base_chunks:
        base_chunks = [text]
    return _apply_overlap(base_chunks, chunk_overlap)


def _safe_output_name(source_name: str, idx: int) -> str:
    stem = Path(source_name).stem or "chunk"
    return f"{stem}_rcs_{idx:03d}.md"


def split_markdown_zip_bytes(
    zip_bytes: bytes,
    *,
    chunk_size: int = 1200,
    chunk_overlap: int = 150,
    separators: Iterable[str] | None = None,
) -> tuple[list[dict], dict[str, str]]:
    manifest: list[dict] = []
    output_files: dict[str, str] = {}
    sep_list = [str(s) for s in (separators or DEFAULT_SEPARATORS)]

    with zipfile.ZipFile(BytesIO(zip_bytes), "r") as zf:
        md_names = [n for n in zf.namelist() if n.lower().endswith(".md")]
        md_names.sort()
        if not md_names:
            raise ValueError("No .md files were found in the uploaded .zip")

        global_index = 1
        for source_name in md_names:
            text = zf.read(source_name).decode("utf-8", errors="ignore")
            chunks = recursive_split_text(
                text,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                separators=sep_list,
            )
            if not chunks:
                continue
            for local_index, chunk in enumerate(chunks, start=1):
                output_name = _safe_output_name(source_name, local_index)
                if output_name in output_files:
                    output_name = f"{Path(source_name).stem}_rcs_{global_index:03d}.md"
                output_files[output_name] = chunk
                manifest.append(
                    {
                        "global_index": global_index,
                        "source_file": source_name,
                        "source_chunk_index": local_index,
                        "output_file": output_name,
                        "char_count": len(chunk),
                        "line_count": chunk.count("\n") + 1,
                        "preview": chunk[:180].replace("\n", " ").strip(),
                    }
                )
                global_index += 1
    return manifest, output_files


def summarize_results(manifest: list[dict], output_files: dict[str, str]) -> dict[str, int]:
    source_files = {item["source_file"] for item in manifest}
    return {
        "input_markdown_files": len(source_files),
        "output_chunks": len(output_files),
        "total_output_characters": sum(len(text) for text in output_files.values()),
    }


def build_output_zip_bytes(manifest: list[dict], output_files: dict[str, str], archive_stem: str) -> bytes:
    stem = Path(archive_stem).stem or "recursive_chunks"
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for output_name, text in output_files.items():
            zf.writestr(output_name, text)
        zf.writestr(
            f"{stem}_recursive_manifest.json",
            json.dumps(manifest, indent=2, ensure_ascii=False),
        )
    return buffer.getvalue()
