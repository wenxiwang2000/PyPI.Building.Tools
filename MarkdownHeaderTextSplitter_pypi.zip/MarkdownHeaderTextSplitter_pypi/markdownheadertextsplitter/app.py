from __future__ import annotations

import streamlit as st

from markdownheadertextsplitter.core import build_zip_bytes, chunk_manifest, split_markdown_into_chunks


st.set_page_config(
    page_title="MarkdownHeaderTextSplitter",
    page_icon="🧩",
    layout="wide",
)

st.title("MarkdownHeaderTextSplitter")
st.caption("Split Markdown into smaller heading-aware chunks for RAG, review, or preprocessing.")

with st.sidebar:
    st.header("Settings")
    target_chunks = st.slider("Target number of chunks", min_value=1, max_value=40, value=6)
    max_heading_level = st.select_slider("Respect headings through level", options=[1, 2, 3, 4, 5, 6], value=3)
    include_preamble = st.checkbox("Keep preamble before first heading", value=True)
    hard_max_chars = st.number_input(
        "Safety cap: max characters per chunk (0 = disabled)",
        min_value=0,
        max_value=50000,
        value=0,
        step=100,
    )

uploaded = st.file_uploader("Drag a Markdown file here", type=["md"])

if uploaded is None:
    st.info("Upload a .md file to preview and export split chunks.")
    st.stop()

raw_bytes = uploaded.read()
text = raw_bytes.decode("utf-8", errors="ignore")

chunks = split_markdown_into_chunks(
    text,
    target_chunks=target_chunks,
    max_heading_level=max_heading_level,
    include_preamble=include_preamble,
    hard_max_chars=hard_max_chars,
)
manifest = chunk_manifest(chunks, uploaded.name)
zip_bytes = build_zip_bytes(chunks, uploaded.name)

col1, col2 = st.columns([1, 2])
with col1:
    st.metric("Output chunks", len(chunks))
    st.metric("Input characters", len(text))
    st.metric("Avg chunk characters", int(sum(len(c) for c in chunks) / max(1, len(chunks))))
    st.download_button(
        label="Download split .zip",
        data=zip_bytes,
        file_name=f"{uploaded.name.rsplit('.', 1)[0]}_chunks.zip",
        mime="application/zip",
    )

with col2:
    st.subheader("Chunk manifest")
    st.dataframe(manifest, use_container_width=True)

st.subheader("Chunk preview")
for item, chunk in zip(manifest, chunks):
    with st.expander(f"{item['file_name']} — {item['char_count']} chars"):
        st.code(chunk, language="markdown")
