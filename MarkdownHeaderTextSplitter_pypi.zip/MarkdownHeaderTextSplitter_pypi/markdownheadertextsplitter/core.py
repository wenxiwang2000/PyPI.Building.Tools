from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
import json
import math
import re
import zipfile
from pathlib import Path
from typing import Iterable, List

HEADING_RE = re.compile(r"^\\?(#{1,6})\s+(.*\S)\s*$")


@dataclass
class Section:
    heading_level: int
    heading_text: str
    content: str

    @property
    def char_count(self) -> int:
        return len(self.content)


def _normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def parse_markdown_sections(
    text: str,
    *,
    max_heading_level: int = 3,
    include_preamble: bool = True,
) -> List[Section]:
    """Split a markdown document into ordered sections based on headings.

    The implementation is intentionally simple and original:
    - Headings up to ``max_heading_level`` start a new section.
    - The heading line is kept inside the section content.
    - Optional preamble text before the first heading becomes its own section.
    """
    text = _normalize_newlines(text).strip("\n")
    if not text:
        return []

    sections: List[Section] = []
    current_lines: List[str] = []
    current_level = 0
    current_title = "Preamble"
    saw_heading = False

    for line in text.split("\n"):
        match = HEADING_RE.match(line)
        if match:
            level = len(match.group(1))
            title = match.group(2).strip()
            if level <= max_heading_level:
                if current_lines and (include_preamble or saw_heading):
                    sections.append(
                        Section(
                            heading_level=current_level,
                            heading_text=current_title,
                            content="\n".join(current_lines).strip() + "\n",
                        )
                    )
                current_lines = [line]
                current_level = level
                current_title = title
                saw_heading = True
                continue
        current_lines.append(line)

    if current_lines and (include_preamble or saw_heading):
        sections.append(
            Section(
                heading_level=current_level,
                heading_text=current_title,
                content="\n".join(current_lines).strip() + "\n",
            )
        )

    if not sections:
        return [Section(heading_level=0, heading_text="Document", content=text + "\n")]
    return sections


def _split_text_by_paragraphs(text: str) -> List[str]:
    parts = [part.strip() for part in re.split(r"\n\s*\n", text) if part.strip()]
    return [part + "\n\n" for part in parts] or [text]


def _split_text_by_size(text: str, target_parts: int) -> List[str]:
    if target_parts <= 1 or len(text) < 2:
        return [text]
    paragraphs = _split_text_by_paragraphs(text)
    if len(paragraphs) >= target_parts:
        total_chars = sum(len(p) for p in paragraphs)
        desired = max(1, math.ceil(total_chars / target_parts))
        out: List[str] = []
        bucket: List[str] = []
        bucket_size = 0
        remaining_parts = target_parts
        remaining_paragraphs = paragraphs[:]

        for para in remaining_paragraphs:
            remaining_paragraphs_left = len(remaining_paragraphs)
            remaining_paragraphs.pop(0)
            bucket.append(para)
            bucket_size += len(para)

            must_close = len(out) + 1 == target_parts
            enough_size = bucket_size >= desired
            enough_remaining = len(remaining_paragraphs) >= (remaining_parts - 1)

            if must_close or (enough_size and enough_remaining):
                out.append("".join(bucket).strip() + "\n")
                bucket = []
                bucket_size = 0
                remaining_parts -= 1

        if bucket:
            out.append("".join(bucket).strip() + "\n")
        return [chunk for chunk in out if chunk.strip()]

    # Fallback: raw char slicing if there are not enough paragraphs.
    text = text.strip()
    step = max(1, math.ceil(len(text) / target_parts))
    out = []
    start = 0
    while start < len(text):
        out.append(text[start : start + step].strip() + "\n")
        start += step
    return [chunk for chunk in out if chunk.strip()]


def _merge_sections_to_target(sections: List[Section], target_chunks: int) -> List[str]:
    if target_chunks <= 1 or len(sections) <= 1:
        return ["\n".join(section.content.strip() for section in sections if section.content.strip()) + "\n"]

    total_chars = sum(section.char_count for section in sections)
    desired = max(1, math.ceil(total_chars / target_chunks))

    chunks: List[str] = []
    bucket: List[str] = []
    bucket_chars = 0
    remaining_sections = sections[:]
    remaining_buckets = target_chunks

    while remaining_sections:
        section = remaining_sections.pop(0)
        bucket.append(section.content.strip())
        bucket_chars += section.char_count

        must_close = len(chunks) + 1 == target_chunks
        enough_size = bucket_chars >= desired
        enough_remaining = len(remaining_sections) >= (remaining_buckets - 1)

        if must_close or (enough_size and enough_remaining):
            chunks.append("\n\n".join(bucket).strip() + "\n")
            bucket = []
            bucket_chars = 0
            remaining_buckets -= 1

    if bucket:
        chunks.append("\n\n".join(bucket).strip() + "\n")

    return [chunk for chunk in chunks if chunk.strip()]


def _expand_sections_to_target(sections: List[Section], target_chunks: int) -> List[str]:
    chunks = [section.content.strip() + "\n" for section in sections if section.content.strip()]
    if not chunks:
        return []

    while len(chunks) < target_chunks:
        idx = max(range(len(chunks)), key=lambda i: len(chunks[i]))
        biggest = chunks[idx]
        if len(biggest) < 400:
            break
        split_parts = _split_text_by_size(biggest, 2)
        if len(split_parts) <= 1:
            break
        chunks = chunks[:idx] + split_parts + chunks[idx + 1 :]

    return chunks


def _apply_hard_max_chars(chunks: Iterable[str], hard_max_chars: int) -> List[str]:
    out: List[str] = []
    for chunk in chunks:
        if hard_max_chars <= 0 or len(chunk) <= hard_max_chars:
            out.append(chunk.strip() + "\n")
            continue
        parts = _split_text_by_size(chunk, max(2, math.ceil(len(chunk) / hard_max_chars)))
        out.extend(part.strip() + "\n" for part in parts if part.strip())
    return out


def split_markdown_into_chunks(
    text: str,
    *,
    target_chunks: int = 6,
    max_heading_level: int = 3,
    include_preamble: bool = True,
    hard_max_chars: int = 0,
) -> List[str]:
    sections = parse_markdown_sections(
        text,
        max_heading_level=max_heading_level,
        include_preamble=include_preamble,
    )
    if not sections:
        return []

    if target_chunks <= 1:
        chunks = ["\n\n".join(section.content.strip() for section in sections).strip() + "\n"]
    elif len(sections) == target_chunks:
        chunks = [section.content.strip() + "\n" for section in sections]
    elif len(sections) > target_chunks:
        chunks = _merge_sections_to_target(sections, target_chunks)
    else:
        chunks = _expand_sections_to_target(sections, target_chunks)

    chunks = _apply_hard_max_chars(chunks, hard_max_chars)
    return [chunk for chunk in chunks if chunk.strip()]


def chunk_manifest(chunks: Iterable[str], source_name: str) -> list[dict]:
    manifest = []
    for index, chunk in enumerate(chunks, start=1):
        line_count = chunk.count("\n") + 1
        manifest.append(
            {
                "chunk_index": index,
                "file_name": f"{Path(source_name).stem}_chunk_{index:03d}.md",
                "char_count": len(chunk),
                "line_count": line_count,
                "preview": chunk[:180].replace("\n", " ").strip(),
            }
        )
    return manifest


def build_zip_bytes(chunks: Iterable[str], source_name: str) -> bytes:
    chunks = list(chunks)
    manifest = chunk_manifest(chunks, source_name)
    stem = Path(source_name).stem or "markdown"

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for item, chunk in zip(manifest, chunks):
            zf.writestr(item["file_name"], chunk)
        zf.writestr(
            f"{stem}_manifest.json",
            json.dumps(manifest, indent=2, ensure_ascii=False),
        )
    return buffer.getvalue()
