from __future__ import annotations

import io
import json
import math
import re
import zipfile
from dataclasses import dataclass
from typing import Iterable

import streamlit as st
from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)


@dataclass
class ChunkRecord:
    index: int
    filename: str
    metadata: dict
    content: str


def sanitize_filename(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return base or "markdown"


def estimate_chunk_size(text: str, desired_chunks: int, min_size: int = 300, max_size: int = 4000) -> int:
    desired_chunks = max(1, desired_chunks)
    approx = math.ceil(len(text) / desired_chunks)
    return max(min_size, min(max_size, approx))


def build_headers(levels: Iterable[str]) -> list[tuple[str, str]]:
    mapping = {"#": "h1", "##": "h2", "###": "h3", "####": "h4", "#####": "h5", "######": "h6"}
    ordered = [h for h in ["#", "##", "###", "####", "#####", "######"] if h in levels]
    return [(h, mapping[h]) for h in ordered]


def split_markdown(text: str, filename: str, heading_levels: list[str], desired_chunks: int, chunk_overlap: int, strip_headers: bool) -> list[ChunkRecord]:
    headers_to_split_on = build_headers(heading_levels)
    if not headers_to_split_on:
        headers_to_split_on = [("#", "h1"), ("##", "h2"), ("###", "h3")]

    header_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=headers_to_split_on,
        strip_headers=strip_headers,
    )
    header_docs = header_splitter.split_text(text)

    target_chunk_size = estimate_chunk_size(text, desired_chunks)
    size_splitter = RecursiveCharacterTextSplitter(
        chunk_size=target_chunk_size,
        chunk_overlap=min(chunk_overlap, max(0, target_chunk_size // 3)),
        separators=["\n\n", "\n", " ", ""],
    )
    final_docs = size_splitter.split_documents(header_docs)

    records: list[ChunkRecord] = []
    stem = sanitize_filename(filename.rsplit(".", 1)[0])
    for idx, doc in enumerate(final_docs, start=1):
        md = {k: v for k, v in doc.metadata.items() if v is not None}
        out_name = f"{stem}_chunk_{idx:03d}.md"
        records.append(ChunkRecord(index=idx, filename=out_name, metadata=md, content=doc.page_content.strip()))
    return records


def chunk_zip_bytes(records: list[ChunkRecord], original_name: str) -> bytes:
    buf = io.BytesIO()
    manifest = []
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for record in records:
            header_lines = ["<!--", f"chunk_index: {record.index}"]
            for key, value in record.metadata.items():
                header_lines.append(f"{key}: {value}")
            header_lines.append("-->\n")
            body = "\n".join(header_lines) + record.content + "\n"
            zf.writestr(record.filename, body)
            manifest.append({
                "chunk_index": record.index,
                "filename": record.filename,
                "metadata": record.metadata,
                "chars": len(record.content),
                "preview": record.content[:160],
            })
        zf.writestr("manifest.json", json.dumps({"source_file": original_name, "chunks": manifest}, indent=2, ensure_ascii=False))
    buf.seek(0)
    return buf.read()


def main() -> None:
    st.set_page_config(page_title="MarkdownHeaderTextSplitter", layout="wide")
    st.title("MarkdownHeaderTextSplitter")
    st.caption("Split Markdown into RAG-ready chunks while respecting heading structure like #, ##, ###.")

    with st.sidebar:
        st.header("Split settings")
        heading_levels = st.multiselect(
            "Respect heading levels",
            ["#", "##", "###", "####", "#####", "######"],
            default=["#", "##", "###"],
        )
        desired_chunks = st.slider("Target chunk count", min_value=1, max_value=100, value=12, step=1)
        chunk_overlap = st.slider("Chunk overlap (characters)", min_value=0, max_value=800, value=150, step=10)
        strip_headers = st.checkbox("Strip Markdown headers from chunk text", value=False)

    uploaded = st.file_uploader("Drag a .md file here", type=["md"])

    if uploaded is None:
        st.info("Upload one Markdown file to preview and export split chunks.")
        st.code(
            "pip install .\nMarkdownHeaderTextSplitter",
            language="bash",
        )
        return

    raw_text = uploaded.getvalue().decode("utf-8", errors="ignore")
    st.subheader("Source overview")
    c1, c2, c3 = st.columns(3)
    c1.metric("Characters", len(raw_text))
    c2.metric("Estimated words", max(1, len(raw_text.split())))
    c3.metric("Requested chunks", desired_chunks)

    records = split_markdown(
        text=raw_text,
        filename=uploaded.name,
        heading_levels=heading_levels,
        desired_chunks=desired_chunks,
        chunk_overlap=chunk_overlap,
        strip_headers=strip_headers,
    )

    if not records:
        st.error("No chunks were produced. Try enabling more heading levels or lowering the target chunk count.")
        return

    st.success(f"Generated {len(records)} chunks.")

    zip_bytes = chunk_zip_bytes(records, uploaded.name)
    zip_name = f"{sanitize_filename(uploaded.name.rsplit('.', 1)[0])}_chunks.zip"
    st.download_button(
        "Download split .md chunks as ZIP",
        data=zip_bytes,
        file_name=zip_name,
        mime="application/zip",
    )

    st.subheader("Chunk preview")
    table_rows = []
    for record in records:
        preview = record.content.replace("\n", " ")[:120]
        table_rows.append({
            "chunk": record.index,
            "filename": record.filename,
            "chars": len(record.content),
            "metadata": json.dumps(record.metadata, ensure_ascii=False),
            "preview": preview,
        })
    st.dataframe(table_rows, use_container_width=True, hide_index=True)

    for record in records:
        title_parts = [f"Chunk {record.index}", f"{len(record.content)} chars"]
        if record.metadata:
            title_parts.append(", ".join(f"{k}={v}" for k, v in record.metadata.items()))
        with st.expander(" | ".join(title_parts)):
            st.markdown(record.content)
            st.code(record.content, language="markdown")


if __name__ == "__main__":
    main()
