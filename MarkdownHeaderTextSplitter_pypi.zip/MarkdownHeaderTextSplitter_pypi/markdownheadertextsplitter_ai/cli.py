from __future__ import annotations

import sys
from pathlib import Path


def main() -> None:
    try:
        from streamlit.web import cli as stcli
    except Exception as exc:  # pragma: no cover
        raise SystemExit(
            "Streamlit is required. Please run: pip install streamlit"
        ) from exc

    app_path = Path(__file__).with_name("app.py")
    sys.argv = ["streamlit", "run", str(app_path), "--server.headless=true"]
    raise SystemExit(stcli.main())
