# MarkdownHeaderTextSplitter

A small, original, heading-aware Markdown splitter with a simple local UI for preparing Markdown files for RAG or inspection.

## What it does

- Accepts a `.md` file in a local UI
- Respects Markdown heading structure like `#`, `##`, and `###`
- Lets you choose how many chunks you want
- Outputs the split Markdown chunks as separate `.md` files inside a downloadable `.zip`
- Keeps the implementation lightweight and original instead of copying third-party splitter code

## Install

```bash
pip install MarkdownHeaderTextSplitter
```

## Run

```bash
MarkdownHeaderTextSplitter
```

This launches a local Streamlit app in your browser.

## Notes

- This package does **not** vendor or copy code from LangChain or other companies.
- The idea of heading-aware splitting is common, but you should still do your own name, trademark, licensing, and patent review before publishing publicly.
- PyPI package-name availability can change over time, so confirm the final project name before upload.

## File structure

```text
MarkdownHeaderTextSplitter_pypi/
  README.md
  LICENSE
  pyproject.toml
  markdownheadertextsplitter/
    __init__.py
    app.py
    cli.py
    core.py
  dist/
    MarkdownHeaderTextSplitter-0.1.0.tar.gz
    markdownheadertextsplitter-0.1.0-py3-none-any.whl
```
